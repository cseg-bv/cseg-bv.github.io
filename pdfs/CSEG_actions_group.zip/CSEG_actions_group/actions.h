//动作组文件
#include <Arduino.h>
#define action_count 2 //动作组数量

static uint8_t action[action_count][40][6] = 
    { 
      // Action Group 1: Switch Blocks
      { 
        {1 ,90  ,90  ,90  ,90  ,90  }, /*Neutral*/
        
        // Pick up block 1
        {1 ,20  ,30 ,180 ,80  ,90  }, /*Over block, effector open*/
        {1 ,20  ,30 ,180 ,135 ,90  }, /*Lower*/
        {1 ,80  ,30 ,180 ,135 ,90  }, /*Close*/
        {1 ,80  ,30 ,180 ,80  ,90  }, /*Lift*/

        // Place block 1 on left diagonal
        {1 ,80  ,40 ,160 ,80  ,150 }, /*Turn left*/
        {1 ,80  ,40 ,160 ,165 ,150 }, /*Lower*/
        {1 ,80  ,40 ,160 ,165 ,150 }, /*Pause here*/ 
        {1 ,20  ,40 ,160 ,165 ,150 }, /*Open*/
        {1 ,20  ,40 ,160 ,80  ,150 }, /*Lift*/
        
        // Pick up block 2
        {1 ,20  ,40 ,160 ,80  ,90  }, /*Turn right*/
        {1 ,20  ,40 ,160 ,165 ,90  }, /*Lower*/
        {1 ,20  ,40 ,160 ,165 ,90  }, /*Lower*/
        {1 ,80  ,40 ,160 ,165 ,90  }, /*Close*/
        {1 ,80  ,40 ,160 ,80  ,90  }, /*Lift*/

        // Place block 2 on right diagonal
        {1 ,80  ,40 ,160 ,80  ,30  }, /*Turn right*/
        {1 ,80  ,40 ,160 ,165 ,30  }, /*Lower*/
        {1 ,80  ,40 ,160 ,165 ,30  }, /*Lower*/ 
        {1 ,20  ,40 ,160 ,165 ,30  }, /*Open*/
        {1 ,20  ,40 ,160 ,80  ,30  }, /*Lift*/

        // Pick up block 1 from left diagonal
        {1 ,20  ,40 ,160 ,80  ,150 }, /*Turn left*/
        {1 ,20  ,40 ,160 ,165 ,150 }, /*Lower*/
        {1 ,20  ,40 ,160 ,165 ,150 }, /*Lower*/
        {1 ,80  ,40 ,160 ,165 ,150 }, /*Close*/
        {1 ,80  ,40 ,160 ,80  ,150 }, /*Lift*/

        // Place block 1 in center
        {1 ,80  ,40 ,160 ,80  ,90  }, /*Turn right*/
        {1 ,80  ,40 ,160 ,165 ,90  }, /*Lower*/
        {1 ,80  ,40 ,160 ,165 ,90  }, /*Lower*/
        {1 ,20  ,40 ,160 ,165 ,90  }, /*Open*/
        {1 ,20  ,40 ,160 ,80  ,90  }, /*Lift*/

        // Pick up block 2 from right diagonal
        {1 ,20  ,40 ,160 ,80  ,30  }, /*Turn right*/
        {1 ,20  ,40 ,160 ,165 ,30  }, /*Lower*/
        {1 ,20  ,40 ,160 ,165 ,30  }, /*Lower*/
        {1 ,80  ,40 ,160 ,165 ,30  }, /*Close*/
        {1 ,80  ,40 ,160 ,80  ,30  }, /*Lift*/

        // Place block 2 in center
        {1 ,80  ,40 ,160 ,80  ,90  }, /*Turn left*/
        {1 ,80  ,30 ,180 ,135 ,90  }, /*Lower*/
        {1 ,20  ,30 ,180 ,135 ,90  }, /*Open*/

        {1 ,90  ,90 ,90  ,90  ,90  }, /*Neutral*/
        
        // Action group completed
        {0 ,0   ,0   ,0   ,0   ,0  }
      },
      
      // Action Group 2: Testing
      { 
        {1 ,90  ,90  ,90  ,90  ,90  }, /*Neutral*/
        {1 ,20  ,30 ,180 ,80  ,90  }, /*Over block, effector open*/
        {1 ,20  ,30 ,180 ,135 ,90  }, /*Lower*/
        {1 ,80  ,30 ,180 ,135 ,90  }, /*Close*/
        {1 ,80  ,30 ,180 ,80  ,90  }, /*Lift*/
        {1 ,80  ,30 ,180 ,135 ,90  }, /*Lower*/
        {1 ,20  ,30 ,180 ,135 ,90  }, /*Open*/
        {1 ,90  ,90 ,90  ,90  ,90  }, /*Neutral*/
        //
        {0 ,0   ,0   ,0   ,0   ,0  }
      }, 
    };